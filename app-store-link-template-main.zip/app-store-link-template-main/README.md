# app-store-link-template

This is a static website template that determines the redirection destination depending on the OS of your device. 

By default, it redirects to the App Store for iOS or Mac, and to the Play Store for other OS.

# Example

You can open the link below to check how this works.

If the OS of your device is Mac then App store will open, otherwise Play Store will open.


https://kakudenbuzo.github.io/app-store-link-template/src/index.html
